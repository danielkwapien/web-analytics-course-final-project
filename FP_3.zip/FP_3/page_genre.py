import streamlit as st
from utils import *
from attractions_module.attractions_analysis import *
from popularity_module.genre_popularity_events_map import *
from streamlit_folium import st_folium
from data import *
from streamlit_plotly_events import plotly_events
import plotly.express as px


st.title("Genre Events Analysis")

df = load_data()

# -------------------------------------------------------------------------------------------------------
#                                                STATE MAP
# -------------------------------------------------------------------------------------------------------

# Get subset necessary to create popularity event map
data_subset = df[['event_name', 'venue_state', 'venue_city', 'segment_name', 'genre_name', 'sub_genre_name', 'start_date', 'venue_latitude', 'venue_longitude', 'min_price', 'max_price']]

# Aggregate data for event counts (per segment)
data_segment_eventcount = data_subset.groupby(['venue_state', 'venue_city', 'segment_name']).agg(event_count=('event_name', 'count')).reset_index()

# Aggregate data for event counts (per segment and genre)
data_segment_classification_eventcount = data_subset.groupby(['venue_state', 'venue_city', 'segment_name', 'genre_name']).agg(event_count=('event_name', 'count')).reset_index()
data_segment_classification_eventcount = data_segment_classification_eventcount.sort_values(by=['event_count'], ascending=False)

# Prepare data for the map (count the number of events happening in each state)
state_counts = (
    data_segment_classification_eventcount.groupby("venue_state")["event_count"]
    .sum()
    .reset_index()
    .rename(columns={"event_count": "total_events"})
)

# Prepare data for the map (count the number of events happening in each state)
state_segment_counts = (
    data_segment_classification_eventcount.groupby(["venue_state", "segment_name"])["event_count"]
    .sum()
    .reset_index()
    .rename(columns={"event_count": "total_events"})
)

# Count the number of unique classifications (genres) happening in each state for each segment and genre
state_segment_genre_counts = (
    data_segment_classification_eventcount.groupby(["venue_state", "segment_name", "genre_name"])["event_count"]
    .sum()
    .reset_index()
    .rename(columns={"event_count": "total_events"})
)

# Load GeoJSON data for US states
with open('data/georef-united-states-of-america-state.geojson', 'r') as f:
    geojson_data = json.load(f)

# Make some changes over the geojson so that the states are not inside a list
for i in range(len(geojson_data["features"])):
  feature = geojson_data["features"][i]
  geojson_data["features"][i]["properties"]["ste_name"] = feature['properties']['ste_name'][0]

segments = df.groupby(['segment_name'])['genre_name'].apply(set).to_dict()

# Allow the user to select a segment dynamically
selected_segment = st.selectbox("Select a Segment", list(segments.keys()))


# Offer the user to select a subgenre or choose "All"
if selected_segment:
    subgenres = ["All"] + sorted(segments[selected_segment])  # Add "All" as the first option
    selected_genre = st.selectbox("Select a specific Genre", subgenres)

price_tab, popularity_tab, attractions_tab = st.tabs(['Price Analysis', 'Genre Popularity Analysis', 'Top Attractions by Genre'])

with price_tab:
    # TODO add price maps and analysis here
    st.markdown(f"## Price Analysis for {selected_segment}")

with popularity_tab:
    # TODO add popularity analysis here
    st.markdown(f"## Popularity Analysis for {selected_segment}")

    # Filter data by segment and genre
    if selected_segment:
        segment_data = state_segment_counts[state_segment_counts["segment_name"] == selected_segment]

        if selected_genre and selected_genre != "All":
            filtered_data = state_segment_genre_counts[
                (state_segment_genre_counts["segment_name"] == selected_segment) &
                (state_segment_genre_counts["genre_name"] == selected_genre)
            ]
        else:
            filtered_data = segment_data
    else:
        filtered_data = state_counts  # Default to overall state counts
    
    # Display the top 10 states table
    if selected_genre and selected_genre != "All":
        st.markdown(f"#### Top 10 States for {selected_segment} - {selected_genre}")
    else:
        st.markdown(f"#### Top 10 States for {selected_segment}")
    
    with st.expander('Top 10 States', expanded=True):

        # Sort the filtered data to get the top 10 states
        top_10_states = (
            filtered_data.nlargest(10, "total_events")
            .rename(columns={"total_events": "Event Count", "venue_state": "State"})
            [["State", "Event Count"]]
            .reset_index(drop=True)
        )
        top_10_states.index += 1

        st.table(top_10_states)
    
    if selected_genre and selected_genre != "All":
        st.markdown(f"#### {selected_segment} - {selected_genre} Events Across All States")
    else:
        st.markdown(f"#### {selected_segment} Events Across All States")

    with st.expander('Events Across All States', expanded=True):
        # Create the map
        event_map = create_map_event_popularity_state(filtered_data, geojson_data)

        # Display the map in Streamlit
        st_data = st_folium(event_map, width=700, height=600)
    
    # Aggregate data by segment_name for fig1
    aggregated_segment_counts = (
        state_segment_counts.groupby("segment_name", as_index=False)["total_events"]
        .sum()
    )

    # General Bar Charts (Default State)
    fig1 = px.bar(
        aggregated_segment_counts,
        x="segment_name",
        y="total_events",
        color="segment_name",
        title="Overall Event Count per Segment (All States)",
        labels={"segment_name": "Segment", "total_events": "Event Count"},
        color_discrete_sequence=px.colors.qualitative.Set2,
    )

    # Aggregate data by genre_name for fig2
    aggregated_genre_counts = (
        state_segment_genre_counts.groupby("genre_name", as_index=False)["total_events"]
        .sum()
    )

    fig2 = px.bar(
        aggregated_genre_counts,
        x="genre_name",
        y="total_events",
        color="genre_name",
        title="Overall Event Count per Genre (All States)",
        labels={"genre_name": "Genre", "total_events": "Event Count"},
        color_discrete_sequence=px.colors.qualitative.Set2,
    )

    # Add reset button
    if st.button("Reset Charts"):
        # Reset charts to default states
        fig1 = px.bar(
                aggregated_segment_counts,
                x="segment_name",
                y="total_events",
                color="segment_name",
                title="Overall Event Count per Segment (All States)",
                labels={"segment_name": "Segment", "total_events": "Event Count"},
                color_discrete_sequence=px.colors.qualitative.Set2,
            )
        
        fig2 = px.bar(
                aggregated_genre_counts,
                x="genre_name",
                y="total_events",
                color="genre_name",
                title="Overall Event Count per Genre (All States)",
                labels={"genre_name": "Genre", "total_events": "Event Count"},
                color_discrete_sequence=px.colors.qualitative.Set2,
            )
        # Re-render the charts to reset to their default values
        with st.expander('Select a State for More Detail', expanded=True):
            st.plotly_chart(fig1, use_container_width=True)
        with st.expander('Select a Segment for More Detail', expanded=True):
            st.plotly_chart(fig2, use_container_width=True)

    else:
        # Proceed with normal flow if reset is not clicked

        st.markdown(f"#### Information Across States")

        # Handle state selection on the map
        clicked_state = None
        if st_data and st_data.get("last_active_drawing"):
            clicked_state = st_data["last_active_drawing"]["properties"].get("ste_name")
            st.write(f"**Selected State:** {clicked_state}")

        # Update the first chart if a state is selected
        if clicked_state:
            filtered_state_data = state_segment_counts[state_segment_counts['venue_state'] == clicked_state]
            if not filtered_state_data.empty:
                fig1 = px.bar(
                    filtered_state_data,
                    x="segment_name",
                    y="total_events",
                    color="segment_name",
                    title=f"Overall Event Count by Segment in {clicked_state}",
                    labels={"segment_name": "Segment", "total_events": "Event Count"},
                    color_discrete_sequence=px.colors.qualitative.Light24,
                )

        # Expander for the first bar chart
        with st.expander('Select a State for More Detail', expanded=True):
            fig1.update_layout(
                title=f"Event Count per Segment ({clicked_state if clicked_state else 'All States'})",  # Dynamic title update
                title_font=dict(size=14, family="Arial, sans-serif", color="black"),
                title_x=0,  # Align title to the left
                title_xanchor='left',  # Anchor the title to the left side
                xaxis_title="Segment",
                yaxis_title="Event Count",
                xaxis=dict(
                    title_font=dict(size=14, family="Arial, sans-serif"),
                    tickfont=dict(size=12, family="Arial, sans-serif"),
                ),
                yaxis=dict(
                    title_font=dict(size=14, family="Arial, sans-serif"),
                    tickfont=dict(size=12, family="Arial, sans-serif"),
                ),
                legend=dict(
                    title="Segment",
                    font=dict(size=12, family="Arial, sans-serif"),
                ),
                margin=dict(t=40, b=40, l=40, r=40),  # Adjust margins
                plot_bgcolor="white",  # Set the background color to white
            )

            selected_segment_event = plotly_events(fig1, click_event=True, key="segment_event")

        # Initialize second chart data
        filtered_genre_data = state_segment_genre_counts

        # Update second chart based on clicks in the first chart
        if selected_segment_event:
            clicked_segment = selected_segment_event[0]["x"]  # Extract clicked segment

            # Filter genre data for the clicked segment
            if clicked_state:
                # Filter for the selected state and segment
                filtered_genre_data = state_segment_genre_counts[
                    (state_segment_genre_counts["venue_state"] == clicked_state) &
                    (state_segment_genre_counts["segment_name"] == clicked_segment)
                ]
                # Aggregate by genre to get the total event count per genre for the selected segment and state
                aggregated_genre_data = filtered_genre_data.groupby("genre_name", as_index=False)["total_events"].sum()
                title = f"Event Count by Genre in {clicked_segment} Segment ({clicked_state})"
            else:
                # Filter only by the clicked segment (all states)
                filtered_genre_data = state_segment_genre_counts[
                    state_segment_genre_counts["segment_name"] == clicked_segment
                ]
                # Aggregate by genre to get the total event count per genre for the selected segment (all states)
                aggregated_genre_data = filtered_genre_data.groupby("genre_name", as_index=False)["total_events"].sum()
                title = f"Event Count by Genre in {clicked_segment} Segment (All States)"

            # Update the second chart with aggregated genre data
            fig2 = px.bar(
                aggregated_genre_data,
                x="genre_name",
                y="total_events",
                color="genre_name",
                title=title,
                labels={"genre_name": "Genre", "total_events": "Event Count"},
                color_discrete_sequence=px.colors.qualitative.Light24,
            )


        # Expander for the second bar chart
        with st.expander('Select a Segment for More Detail', expanded=True):
            
            st.plotly_chart(fig2, use_container_width=True)
        
    
    



with attractions_tab:
    if selected_genre == "All":
        st.header(f"Top Attractions in {selected_segment}")
    else:
        st.header(f"Top Attractions in {selected_genre}")

    # numoto dispaly from 10 to 30 in steps of 5
    num_attractions = st.selectbox('Number of Genres to Display:', options=range(10, 31, 5))


    attractions_df = get_top_attractions(df, selected_segment, selected_genre, num_attractions)

    # format and displayt the top attractions
    st.table(attractions_df)